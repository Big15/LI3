#ifndef CODIGO_H
#define CODIGO_H

typedef struct cod* Codigo;

char* get_codigo(Codigo cod);

Codigo set_codigo(Codigo cod, char* s);

#endif 

